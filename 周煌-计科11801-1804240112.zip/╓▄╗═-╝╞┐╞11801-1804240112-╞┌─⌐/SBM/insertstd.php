<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>学生后台管理系统</title>
    <meta name="viewport" content="initial-scale=1.0,user-scalable=no,maximum-scale=1,width=device-width">
    <meta name="viewport" media="(device-height: 568px)" content="initial-scale=1.0,user-scalable=no,maximum-scale=1">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="stylesheet" href="css/gongyong.css">
    <script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>

</head>

<body>

<div class="head">
    <span class="head_lf"><a href="insertstd.php">学生基本信息</a></span>

    <span class="head_ce"><a href="insertmajor.php">学生学籍信息</a></span>

    <span class="head_rg"><a href="insertcj.php">学生成绩录入</a></span>
</div>

<div class="zhuce">
    <form method="post">
        <div class="text">
            <span>学 号</span>
            <input type="text" placeholder="请输入学号" name="no" class="input">
        </div>
        <div class="text">
            <span>姓 名</span>
            <input type="text" placeholder="请输入姓名" name="name" class="input">
        </div>
        <div class="text">
            <span>性 别</span>
            <input type="text" placeholder="请输入性别" name="sex" class="input">
        </div>
        <div class="text">
            <span>民 族</span>
            <input type="text" placeholder="请输入民族" name="mz" class="input">
        </div>
        <div class="text">
            <span>政治面貌</span>
            <input type="text" placeholder="请输入政治面貌" name="zzmm" class="input">
        </div>
        <div class="text">
            <span>身份证号</span>
            <input type="text" placeholder="请输入身份证号" name="card" class="input">
        </div>
        <div class="text">
            <span>电子邮箱</span>
            <input type="text" placeholder="请输入电子邮箱" name="email" class="input">
        </div>
        <div class="text">
            <span>QQ账号</span>
            <input type="text" placeholder="请输入QQ账号" name="qq" class="input">
        </div>
        <div class="text">
            <span>电话号码</span>
            <input type="text" placeholder="请输入号码" name="phone" class="input">
        </div>
        <div class="text">
            <span>户籍地址</span>
            <input type="text" placeholder="请输入户籍地址" name="hjd" class="input">
        </div>

        <div class="btndl"><input type="submit" name="sub" value="添 加 学 生 信 息"></div>
    </form>
</div>

<div style="text-align:center;">
</div>

<?php
if(empty($_COOKIE['user']) || empty($_COOKIE['pwd'])){
    echo "<script>alert('您没有登录系统，无法使用学生后台管理系统！')</script>";
    echo "<script>location.href='index.php'</script>";
}
$conn = mysqli_connect("127.0.0.1","root","","test") or die("mysql连接失败");
mysqli_set_charset($conn, 'utf8');
if(!empty($_POST['sub'])){
    $no = $_POST['no'];
    $name = $_POST['name'];
    $sex = $_POST['sex'];
    $mz = $_POST['mz'];
    $zzmm = $_POST['zzmm'];
    $card = $_POST['card'];
    $email = $_POST['email'];
    $qq = $_POST['qq'];
    $phone = $_POST['phone'];
    $hjd = $_POST['hjd'];
    $sql = "insert into `mystudent`(`no`,`name`,`sex`,`mz`,`zzmm`,`card`,`email`,`qq`,`phone`,`hjd`) values ('$no','$name','$sex','$mz','$zzmm','$card','$email','$qq','$phone','$hjd')";
//        $sql = "insert into wb(id,title,dates,contents) values (null,'$title',now(),'$con')";
    mysqli_query($conn, $sql);
    if(mysqli_affected_rows($conn) > 0){
        header("location:insertmajor.php?mno=".$no);
    }
}
mysqli_close($conn);
?>

</body>
</html>
