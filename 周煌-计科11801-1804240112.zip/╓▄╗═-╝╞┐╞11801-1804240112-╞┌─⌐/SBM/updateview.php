<html>
<head>
    <title>学生后台管理系统</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="css/view.css" rel="stylesheet" type="text/css" />
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">学生管理系统</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="view.php">主页面 <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    学生管理
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="insertstd.php">学生信息添加</a>
                    <a class="dropdown-item" href="updateview.php">学生信息修改</a>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view.php?out=1" tabindex="-1" aria-disabled="true">退出登录</a>
            </li>
        </ul>
        <form class="form-inline my-2 my-lg-0">
            <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search" name="sc">
            <input class="btn btn-outline-success my-2 my-sm-0" type="submit" name="sub" value="Search">
        </form>
    </div>
</nav>
<br><br><br>
<div>
    <?php
    if(empty($_COOKIE['user']) || empty($_COOKIE['pwd'])){
        echo "<script>alert('您没有登录系统，无法使用学生后台管理系统！')</script>";
        echo "<script>location.href='index.php'</script>";
    }
    $conn = mysqli_connect("127.0.0.1","root","","test") or die("mysql连接失败");
    mysqli_set_charset($conn, 'utf8');
    //共有多少条记录，从数据库中表获取
    $rowCount = 0;
    //每页显示多少条记录
    $pageSize = 4;
    //共有多少页，需要计算得出
    $pageCount = 0;
    //显示第几页，用户输入
    $pageNow = 1;

    if(!empty($_GET['pageNow'])){
        $pageNow = $_GET['pageNow'];
    }
    $flag = false;
    if(!empty($_GET['flag'])){
        $flag = $_GET['flag'];
    }
    $text = "";
    if(!empty($_GET['sub'])){
        $sc = $_GET['sc'];
        $text = $sc;
        $flag = true;
    }
    if(!empty($_GET['text'])){
        $text = $_GET['text'];
    }
    if($flag){
        $w = "`name` like '%$text%'";
    }else{
        $w = 1;
    }
    $sqlCount = "select count(name) from `mystudent` where $w";
    $query = mysqli_query($conn,$sqlCount);
    //获取到一共有多少条记录
    if($rs = mysqli_fetch_row($query)){
        $rowCount = $rs[0];
    }
    $pageCount = ceil($rowCount/$pageSize);
    //$sql = "select * from `wb` order by `id` desc";
    $n = ($pageNow-1)*$pageSize;
    //分页显示
    $sql = "select * from `mystudent` where $w order by `no` desc limit $n,$pageSize";
    $result = mysqli_query($conn, $sql);
    while($rs = mysqli_fetch_assoc($result)) {
        ?>
        <h4><?php echo $rs['no'];?>&nbsp;&nbsp;&nbsp;<?php echo $rs['name'];?> |<a href="updateone.php?no=<?php echo $rs['no'];?>">个人信息修改</a> |<a href="updatetwo.php?no=<?php echo $rs['no'];?>">学籍信息修改</a> |<a href="updatethree.php?no=<?php echo $rs['no'];?>">成绩信息修改</a> |<a href="delete.php?no=<?php echo $rs['no'];?>">删除记录</a></h4>
        <hr>
        <?php
    }
    ?>
    <nav aria-label="Page navigation example">
        <ul class="pagination">
            <?php
            if ($pageNow > 1){
                $prePage = $pageNow - 1;
                echo "<li class=\"page-item\"><a class=\"page-link\" href='updateview.php?pageNow=$prePage&flag=$flag&text=$text' aria-label=\"Previous\"><span aria-hidden=\"true\">&laquo;</span></a></li>";
            }
            for ($i = 1; $i <= $pageCount ;$i++){
                echo "<li class=\"page-item\"><a class=\"page-link\" href='updateview.php?pageNow=$i&flag=$flag&text=$text'>$i</a></li>";
            }
            if ($pageNow < $pageCount){
                $nextPage = $pageNow + 1;
                echo "<li class=\"page-item\"><a class=\"page-link\" href='updateview.php?pageNow=$nextPage&flag=$flag&text=$text' aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
            }
            ?>
        </ul>
    </nav>
    <?php
    /*$headPage = $pageNow;
    if(($headPage-5) >= 1){
        $headPage -= 5;
    }
    echo "<a href='view.php?pageNow=$headPage&flag=$flag&text=$text'><<</a>&nbsp;&nbsp;";
    $afterPage = $pageNow;
    if(($afterPage+5) <= $pageCount){

        $afterPage += 5;
    }
    echo "<a href='view.php?pageNow=$afterPage&flag=$flag&text=$text'>>></a>";*/
    mysqli_close($conn);
    ?>
    <form action="updateview.php">
        跳转到：<input type="text" name="pageNow" />
        <input type="submit" value="GO"/>
    </form>
</div>
</body>
</html>
