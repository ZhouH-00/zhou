<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>学生后台管理系统</title>
    <meta name="viewport" content="initial-scale=1.0,user-scalable=no,maximum-scale=1,width=device-width">
    <meta name="viewport" media="(device-height: 568px)" content="initial-scale=1.0,user-scalable=no,maximum-scale=1">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="stylesheet" href="css/gongyong.css">
    <script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>

</head>

<body>

<div class="head">
    <span class="head_lf"><a href="insertstd.php">学生基本信息</a></span>

    <span class="head_ce"><a href="insertmajor.php">学生学籍信息</a></span>

    <span class="head_rg"><a href="insertcj.php">学生成绩录入</a></span>
</div>

<div class="zhuce">
    <form method="post">
        <div class="text">
            <span>php</span>
            <input type="text" placeholder="请输入分数" name="pp" class="input">
        </div>
        <div class="text">
            <span>oracle</span>
            <input type="text" placeholder="请输入分数" name="oracle" class="input">
        </div>
        <div class="text">
            <span>嵌入式</span>
            <input type="text" placeholder="请输入分数" name="qrs" class="input">
        </div>
        <div class="text">
            <span>软件工程</span>
            <input type="text" placeholder="请输入分数" name="rjgc" class="input">
        </div>
        <div class="text">
            <span>Linux</span>
            <input type="text" placeholder="请输入分数" name="linux" class="input">
        </div>
        <div class="text">
            <span>编译原理</span>
            <input type="text" placeholder="请输入分数" name="byyl" class="input">
        </div>

        <div class="btndl"><input type="submit" name="btn" value="录入 成 绩 信 息"></div>
    </form>
</div>

<div style="text-align:center;">
</div>

<?php
if(empty($_COOKIE['user']) || empty($_COOKIE['pwd'])){
    echo "<script>alert('您没有登录系统，无法使用学生后台管理系统！')</script>";
    echo "<script>location.href='index.php'</script>";
}
$conn = mysqli_connect("127.0.0.1","root","","test") or die("mysql连接失败");
mysqli_set_charset($conn, 'utf8');
if(!empty($_POST['btn'])){
    $cno = $_GET['cno'];
    $pp = $_POST['pp'];
    $oracle = $_POST['oracle'];
    $qrs = $_POST['qrs'];
    $rjgc = $_POST['rjgc'];
    $linux = $_POST['linux'];
    $byyl = $_POST['byyl'];
    $sql = "insert into `mycj`(`cno`,`php`,`oracle`,`qrs`,`rjgc`,`linux`,`byyl`) values ('$cno','$pp','$oracle','$qrs','$rjgc','$linux','$byyl')";
    mysqli_query($conn, $sql);
    if(mysqli_affected_rows($conn) > 0){
        header("location:view.php");
    }
}
mysqli_close($conn);
?>

</body>
</html>
