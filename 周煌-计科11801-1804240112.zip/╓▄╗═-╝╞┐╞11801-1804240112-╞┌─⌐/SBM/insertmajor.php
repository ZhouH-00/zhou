<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>学生后台管理系统</title>
    <meta name="viewport" content="initial-scale=1.0,user-scalable=no,maximum-scale=1,width=device-width">
    <meta name="viewport" media="(device-height: 568px)" content="initial-scale=1.0,user-scalable=no,maximum-scale=1">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="stylesheet" href="css/gongyong.css">
    <script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>

</head>

<body>

<div class="head">
    <span class="head_lf"><a href="insertstd.php">学生基本信息</a></span>

    <span class="head_ce"><a href="insertmajor.php">学生学籍信息</a></span>

    <span class="head_rg"><a href="insertcj.php">学生成绩录入</a></span>
</div>

<div class="zhuce">
    <form method="post">
        <div class="text">
            <span>学 历</span>
            <input type="text" placeholder="请输入学历" name="xl" class="input">
        </div>
        <div class="text">
            <span>学 制</span>
            <input type="text" placeholder="请输入学制" name="xz" class="input">
        </div>
        <div class="text">
            <span>学科门类</span>
            <input type="text" placeholder="请输入学科门类" name="xkml" class="input">
        </div>
        <div class="text">
            <span>专业名称</span>
            <input type="text" placeholder="请输入专业名称" name="mname" class="input">
        </div>
        <div class="text">
            <span>所在学院</span>
            <input type="text" placeholder="请输入所在学院" name="mxy" class="input">
        </div>
        <div class="text">
            <span>所在班级</span>
            <input type="text" placeholder="请输入所在班级" name="mclass" class="input">
        </div>

        <div class="btndl"><input type="submit" name="btn" value="添 加 学 籍 信 息"></div>
    </form>
</div>

<div style="text-align:center;">
</div>

<?php
if(empty($_COOKIE['user']) || empty($_COOKIE['pwd'])){
    echo "<script>alert('您没有登录系统，无法使用学生后台管理系统！')</script>";
    echo "<script>location.href='index.php'</script>";
}
$conn = mysqli_connect("127.0.0.1","root","","test") or die("mysql连接失败");
mysqli_set_charset($conn, 'utf8');
if(!empty($_POST['btn'])){
    $mno = $_GET['mno'];
    $xl = $_POST['xl'];
    $xz = $_POST['xz'];
    $xkml = $_POST['xkml'];
    $mname = $_POST['mname'];
    $mxy = $_POST['mxy'];
    $mclass = $_POST['mclass'];
    $sql = "insert into `mymajor`(`mno`,`xl`,`xz`,`xkml`,`mname`,`mxy`,`mclass`) values ('$mno','$xl','$xz','$xkml','$mname','$mxy','$mclass')";
    mysqli_query($conn, $sql);
    if(mysqli_affected_rows($conn) > 0){
        header("location:insertcj.php?cno=".$mno);
    }
}
mysqli_close($conn);
?>

</body>
</html>
