<?php
if(!empty($_POST['btn'])){
    $user = $_POST['user'];
    $pwdone = $_POST['pwdone'];
    $pwdtwo = $_POST['pwdtwo'];
    if($user=="" || $pwdone==""){
        echo "<script>alert('账号或密码不能为空！')</script>";
    }
    else {
        if (strcmp($pwdone, $pwdtwo) == 0) {
            $conn = mysqli_connect("127.0.0.1", "root", "", "test") or die("mysql连接失败");
            mysqli_set_charset($conn, 'utf8');
            $number = 0;
            $sqlone = "select count(username) from myuser where `username` = '$user'";
            $result = mysqli_query($conn, $sqlone);
            $rs = mysqli_fetch_row($result);
            $number = $rs[0];
            if ($number == 1) {
                echo "<script>alert('注册用户账号重复！');</script>";
            } else {
                $sqltwo = "insert into myuser values ('$user','$pwdone')";
                mysqli_query($conn, $sqltwo);
                if (mysqli_affected_rows($conn) > 0) {
                    header("location:view.php");
                } else {
                    echo "<script> alert('注册账号失败！');</script>";
                }
            }
            mysqli_close($conn);
        } else {
            echo "<script> alert('密码输入不一致！');</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>txt</title>

    <link rel="stylesheet" type="text/css" href="css/mystyle.css">

    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/vector.js"></script>

</head>
<body>

<div id="container">
    <div id="output">
        <div class="containerT">
            <h1>用户注册</h1>
            <form class="form" id="entry_form" method="post">
                <input type="text" placeholder="用户名" id="entry_name" name="user">
                <input type="password" placeholder="密码" id="entry_password" name="pwdone">
                <input type="password" placeholder="确认密码" id="entry_password" name="pwdtwo">
                <input type="submit" name="btn" id="entry_btn" value="注册"/>
                <div id="prompt" class="prompt"></div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(function(){
        Victor("container", "output");   //登录背景函数
        $("#entry_name").focus();
        $(document).keydown(function(event){
            if(event.keyCode==13){
                $("#entry_btn").click();
            }
        });
    });
</script>
</body>
</html>
