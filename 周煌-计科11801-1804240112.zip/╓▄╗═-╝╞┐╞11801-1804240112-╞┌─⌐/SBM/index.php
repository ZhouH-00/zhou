<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>学生后台管理系统</title>
    <link href="css/login.css" rel="stylesheet" type="text/css" />
    <style type="text/css">
        .reg-bar{
            width: 300px;
            margin:20px auto 0;
            font-size: 14px;
            overflow: hidden;
        }
        .reg-bar .reg{
            float:left;
        }
        .reg-bar .forget{
            float:right;
        }
    </style>
</head>

<body>
<div class="login_box">
    <div class="login_l_img"><img src="img/login-img.png" /></div>
    <div class="login">
        <div class="login_logo"><a href="#"><img src="img/login_logo.png" /></a></div>
        <div class="login_name">
            <p>学生后台管理系统</p>
        </div>
        <form method="post">
            <input name="username" type="text"  value="用户名" onfocus="this.value=''" onblur="if(this.value==''){this.value='用户名'}">
            <span id="password_text" onclick="this.style.display='none';document.getElementById('password').style.display='block';document.getElementById('password').focus().select();" >密码</span>
            <input name="password" type="password" id="password" style="display:none;" onblur="if(this.value==''){document.getElementById('password_text').style.display='block';this.style.display='none'};"/>
            <input value="登录" name="sub" style="width:100%;" type="submit">
            <div class="reg-bar">
                <a class="reg" href="register.php">注册</a>
                <a class="forget" href="">忘记密码</a>
            </div>
        </form>
    </div>
</div>
<?php
$conn = mysqli_connect("127.0.0.1","root","","test") or die("mysql连接失败");
mysqli_set_charset($conn, 'utf8');
if(!empty($_POST['sub'])){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $number = 0;
    $sqlcount = "select count(username) from myuser where `username`='$username' and `password`='$password'";
    $result = mysqli_query($conn,$sqlcount);
    if($rs = mysqli_fetch_row($result)){
        $number = $rs[0];
    }
    if($number == 1){
        setcookie('user',"$username",time()+3600);
        setcookie('pwd',"$password",time()+3600);
        header("location:view.php");
    }else{
        echo "<script>alert('用户名或密码错误，请重新输入！')</script>";
    }
}
mysqli_close($conn);
?>
</body>
</html>

