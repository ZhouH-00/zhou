<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>学生后台管理系统</title>
    <meta name="viewport" content="initial-scale=1.0,user-scalable=no,maximum-scale=1,width=device-width">
    <meta name="viewport" media="(device-height: 568px)" content="initial-scale=1.0,user-scalable=no,maximum-scale=1">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="stylesheet" href="css/gongyong.css">
    <script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>

</head>

<body>

<div class="head">
    <span class="head_lf"><a href="#"></a></span>

    <span class="head_ce"><a href="#">学生基本信息</a></span>

    <span class="head_rg"><a href="#"></a></span>
</div>

<div class="zhuce">
    <form method="post">
        <?php
        if(empty($_COOKIE['user']) || empty($_COOKIE['pwd'])){
            echo "<script>alert('您没有登录系统，无法使用学生后台管理系统！')</script>";
            echo "<script>location.href='index.php'</script>";
        }
        $conn = mysqli_connect("127.0.0.1","root","","test") or die("mysql连接失败");
        mysqli_set_charset($conn, 'utf8');
        if(!empty($_GET['no'])){
        $no = $_GET['no'];
        $sql = "select * from `mystudent` where `no` = '$no'";
        $result = mysqli_query($conn, $sql);
        while ($rs = mysqli_fetch_assoc($result)) {
        ?>
        <div class="text">
            <span>学 号</span>
            <input type="text" name="no" class="input" value="<?php echo $rs['no']?>">
        </div>
        <div class="text">
            <span>姓 名</span>
            <input type="text" name="name" class="input" value="<?php echo $rs['name']?>">
        </div>
        <div class="text">
            <span>性 别</span>
            <input type="text" name="sex" class="input" value="<?php echo $rs['sex']?>">
        </div>
        <div class="text">
            <span>民 族</span>
            <input type="text" name="mz" class="input" value="<?php echo $rs['mz']?>">
        </div>
        <div class="text">
            <span>政治面貌</span>
            <input type="text" name="zzmm" class="input" value="<?php echo $rs['zzmm']?>">
        </div>
        <div class="text">
            <span>身份证号</span>
            <input type="text" name="card" class="input" value="<?php echo $rs['card']?>">
        </div>
        <div class="text">
            <span>电子邮箱</span>
            <input type="text" name="email" class="input" value="<?php echo $rs['email']?>">
        </div>
        <div class="text">
            <span>QQ账号</span>
            <input type="text" name="qq" class="input" value="<?php echo $rs['qq']?>">
        </div>
        <div class="text">
            <span>电话号码</span>
            <input type="text" name="phone" class="input" value="<?php echo $rs['phone']?>">
        </div>
        <div class="text">
            <span>户籍地址</span>
            <input type="text" name="hjd" class="input" value="<?php echo $rs['hjd']?>">
        </div>

        <div class="btndl"><input type="submit" name="sub" value="返 回 主 页 面"></div>
    </form>
</div>

<div style="text-align:center;">
</div>

<?php
}
}
if(!empty($_POST['sub'])){
    header("location:view.php");
}
mysqli_close($conn);
?>

</body>
</html>
