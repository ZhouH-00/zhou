<?php
$conn = mysqli_connect("127.0.0.1","root","","test") or die("mysql连接失败");
mysqli_set_charset($conn, 'utf8');
if(!empty($_GET['no'])){
    $no = $_GET['no'];
    $sqlstd = "delete from `mystudent` where `no` = '$no'";
    $results = mysqli_query($conn, $sqlstd);
    if($results!=null){
        $sqlmajor = "delete from `mystudent` where `no` = '$no'";
        $resultm = mysqli_query($conn, $sqlmajor);
        if($resultm!=null){
            $sqlcj = "delete from `mystudent` where `no` = '$no'";
            $resultc = mysqli_query($conn, $sqlcj);
            if($resultc!=null){
                header("location:view.php");
            }
        }
    }
}
mysqli_close($conn);
?>