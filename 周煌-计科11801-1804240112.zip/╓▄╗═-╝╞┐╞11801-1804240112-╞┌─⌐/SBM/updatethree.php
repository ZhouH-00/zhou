<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>学生后台管理系统</title>
    <meta name="viewport" content="initial-scale=1.0,user-scalable=no,maximum-scale=1,width=device-width">
    <meta name="viewport" media="(device-height: 568px)" content="initial-scale=1.0,user-scalable=no,maximum-scale=1">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="stylesheet" href="css/gongyong.css">
    <script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>

</head>

<body>

<div class="head">
    <span class="head_lf"><a href="#"></a></span>

    <span class="head_ce"><a href="#">学生成绩修改</a></span>

    <span class="head_rg"><a href="#"></a></span>
</div>

<div class="zhuce">
    <form method="post">
        <?php
        if(empty($_COOKIE['user']) || empty($_COOKIE['pwd'])){
            echo "<script>alert('您没有登录系统，无法使用学生后台管理系统！')</script>";
            echo "<script>location.href='index.php'</script>";
        }
        $conn = mysqli_connect("127.0.0.1","root","","test") or die("mysql连接失败");
        mysqli_set_charset($conn, 'utf8');
        if(!empty($_GET['no'])){
        $cno = $_GET['no'];
        $sql = "select * from `mycj` where `cno` = '$cno'";
        $result = mysqli_query($conn, $sql);
        while ($rs = mysqli_fetch_assoc($result)) {
        ?>
        <div class="text">
            <span>php</span>
            <input type="text" name="pp" class="input" value="<?php echo $rs['php']?>">
        </div>
        <div class="text">
            <span>oracle</span>
            <input type="text" name="oracle" class="input" value="<?php echo $rs['oracle']?>">
        </div>
        <div class="text">
            <span>嵌入式</span>
            <input type="text" name="qrs" class="input" value="<?php echo $rs['qrs']?>">
        </div>
        <div class="text">
            <span>软件工程</span>
            <input type="text" name="rjgc" class="input" value="<?php echo $rs['rjgc']?>">
        </div>
        <div class="text">
            <span>Linux</span>
            <input type="text" name="linux" class="input" value="<?php echo $rs['linux']?>">
        </div>
        <div class="text">
            <span>编译原理</span>
            <input type="text" name="byyl" class="input" value="<?php echo $rs['byyl']?>">
        </div>

        <div class="btndl"><input type="submit" name="btn" value="修 改 成 绩 信 息"></div>
    </form>
</div>

<div style="text-align:center;">
</div>

<?php
}
}
if(!empty($_POST['btn'])){
    $pp = $_POST['pp'];
    $oracle = $_POST['oracle'];
    $qrs = $_POST['qrs'];
    $rjgc = $_POST['rjgc'];
    $linux = $_POST['linux'];
    $byyl = $_POST['byyl'];
    $sqlthree = "update `mycj` set `php`='$pp',`oracle`='$oracle',`qrs`='$qrs',`rjgc`='$rjgc',`linux`='$linux',`byyl`='$byyl' where `cno`='$cno'";
    mysqli_query($conn, $sqlthree);
    if(mysqli_affected_rows($conn) > 0){
        header("location:updateview.php");
    }
}
mysqli_close($conn);
?>

</body>
</html>
