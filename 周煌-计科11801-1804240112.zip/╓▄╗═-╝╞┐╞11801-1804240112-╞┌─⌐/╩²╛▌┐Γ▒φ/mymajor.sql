/*
Navicat MySQL Data Transfer

Source Server         : hrg
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-06-10 21:40:43
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `mymajor`
-- ----------------------------
DROP TABLE IF EXISTS `mymajor`;
CREATE TABLE `mymajor` (
  `mno` varchar(40) CHARACTER SET utf8 NOT NULL,
  `xl` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `xz` varchar(10) CHARACTER SET utf8 DEFAULT '',
  `xkml` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `mname` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `mxy` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  `mclass` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`mno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of mymajor
-- ----------------------------
INSERT INTO `mymajor` VALUES ('201751025074', '本科', '4', '工科', '计算机科学与技术', '计算机信息与工程学院', '1班');
INSERT INTO `mymajor` VALUES ('201733445566', '本科', '4', '工科', '计算机科学与技术', '计算机信息与工程学院', '2班');
INSERT INTO `mymajor` VALUES ('201723025004', '本科', '4', '工科', '计算机科学与技术', '计算机信息与工程学院', '2班');
