/*
Navicat MySQL Data Transfer

Source Server         : hrg
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-06-10 21:40:58
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `mystudent`
-- ----------------------------
DROP TABLE IF EXISTS `mystudent`;
CREATE TABLE `mystudent` (
  `no` varchar(40) CHARACTER SET utf8 NOT NULL,
  `name` varchar(40) CHARACTER SET utf8 DEFAULT '',
  `sex` varchar(10) CHARACTER SET utf8 DEFAULT '',
  `mz` varchar(20) CHARACTER SET utf8 DEFAULT '',
  `zzmm` varchar(20) CHARACTER SET utf8 DEFAULT '',
  `card` varchar(40) CHARACTER SET utf8 DEFAULT '',
  `email` varchar(40) CHARACTER SET utf8 DEFAULT '',
  `qq` varchar(20) CHARACTER SET utf8 DEFAULT '',
  `phone` varchar(20) CHARACTER SET utf8 DEFAULT '',
  `hjd` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of mystudent
-- ----------------------------
INSERT INTO `mystudent` VALUES ('201751025074', '黄瑞国', '男', '汉', '积极分子', '511011202003058899', '1348853977@qq.com', '1348852977', '18845099010', '四川省内江市');
INSERT INTO `mystudent` VALUES ('201733445566', '张儿子', '女', '汉', '党员', '511011202008098778', '12345678912@qq.com', '12345678912', '18845042414', '山西太原');
INSERT INTO `mystudent` VALUES ('201723025004', '陶儿子', '男', '汉', '积极分子', '511011202008094455', '19045042112@qq.com', '19045042112', '18845043366', '安徽');
