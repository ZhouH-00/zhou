/*
Navicat MySQL Data Transfer

Source Server         : hrg
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-06-10 21:40:29
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `mycj`
-- ----------------------------
DROP TABLE IF EXISTS `mycj`;
CREATE TABLE `mycj` (
  `cno` varchar(40) CHARACTER SET utf8 NOT NULL,
  `php` varchar(10) CHARACTER SET utf8 DEFAULT '',
  `oracle` varchar(10) CHARACTER SET utf8 DEFAULT '',
  `qrs` varchar(10) CHARACTER SET utf8 DEFAULT '',
  `rjgc` varchar(10) CHARACTER SET utf8 DEFAULT '',
  `linux` varchar(10) CHARACTER SET utf8 DEFAULT '',
  `byyl` varchar(10) CHARACTER SET utf8 DEFAULT '',
  PRIMARY KEY (`cno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of mycj
-- ----------------------------
INSERT INTO `mycj` VALUES ('201751025074', '100', '100', '100', '100', '100', '100');
INSERT INTO `mycj` VALUES ('201733445566', '100', '100', '100', '100', '100', '100');
INSERT INTO `mycj` VALUES ('201723025004', '100', '100', '100', '100', '100', '100');
